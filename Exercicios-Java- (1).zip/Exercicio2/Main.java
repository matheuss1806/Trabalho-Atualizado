package Exercicio2;

public class Main {
    public static void main(String[] args) {
        Livro meuLivro = new Livro("O Senhor dos Anéis", "J.R.R. Tolkien", 1954);


        meuLivro.exibirInfo();
    }
}