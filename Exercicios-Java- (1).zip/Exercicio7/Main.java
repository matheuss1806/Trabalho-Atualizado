package Exercicio7;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static List<Produto> estoque = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcao;

        do {
            System.out.println("Menu:");
            System.out.println("1. Adicionar Produto");
            System.out.println("2. Atualizar Produto");
            System.out.println("3. Remover Produto");
            System.out.println("4. Gerar Relatório de Estoque");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // Consumir a nova linha

            switch (opcao) {
                case 1:
                    adicionarProduto(scanner);
                    break;
                case 2:
                    atualizarProduto(scanner);
                    break;
                case 3:
                    removerProduto(scanner);
                    break;
                case 4:
                    gerarRelatorio();
                    break;
                case 0:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        } while (opcao != 0);
    }

    private static void adicionarProduto(Scanner scanner) {
        System.out.print("Nome do produto: ");
        String nome = scanner.nextLine();
        System.out.print("Código do produto: ");
        String codigo = scanner.nextLine();
        System.out.print("Preço do produto: ");
        double preco = scanner.nextDouble();
        System.out.print("Quantidade em estoque: ");
        int quantidade = scanner.nextInt();
        estoque.add(new Produto(nome, codigo, preco, quantidade));
        System.out.println("Produto adicionado com sucesso!");
    }

    private static void atualizarProduto(Scanner scanner) {
        System.out.print("Código do produto a ser atualizado: ");
        String codigo = scanner.nextLine();
        for (Produto produto : estoque) {
            if (produto.getCodigo().equals(codigo)) {
                System.out.print("Novo preço: ");
                double novoPreco = scanner.nextDouble();
                produto.atualizarPreco(novoPreco);
                System.out.print("Nova quantidade: ");
                int novaQuantidade = scanner.nextInt();
                produto.setQuantidade(novaQuantidade);
                System.out.println("Produto atualizado com sucesso!");
                return;
            }
        }
        System.out.println("Produto não encontrado.");
    }

    private static void removerProduto(Scanner scanner) {
        System.out.print("Código do produto a ser removido: ");
        String codigo = scanner.nextLine();
        for (Produto produto : estoque) {
            if (produto.getCodigo().equals(codigo)) {
                estoque.remove(produto);
                System.out.println("Produto removido com sucesso!");
                return;
            }
        }
        System.out.println("Produto não encontrado.");
    }

    private static void gerarRelatorio() {
        System.out.println("Relatório de Estoque:");
        double valorTotal = 0;
        for (Produto produto : estoque) {
            System.out.println(produto);
            valorTotal += produto.getPreco() * produto.getQuantidade();
        }
        System.out.println("Valor total em estoque: " + valorTotal);
    }
}